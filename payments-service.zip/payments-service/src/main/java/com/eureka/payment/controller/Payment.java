package com.eureka.payment.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class Payment {

	
	@RequestMapping("/payment/{amount}")
	public String Payments(@PathVariable int amount)
	{
		return "payment is completed with amount of rs="+amount;
	}
}
