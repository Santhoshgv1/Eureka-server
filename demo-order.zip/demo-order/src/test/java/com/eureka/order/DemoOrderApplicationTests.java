package com.eureka.order;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoOrderApplicationTests {

	@Test
	void contextLoads() {
	}

}
